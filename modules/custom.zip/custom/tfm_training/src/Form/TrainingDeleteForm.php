<?php

namespace Drupal\tfm_training\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Training entities.
 *
 * @ingroup tfm_training
 */
class TrainingDeleteForm extends ContentEntityDeleteForm {


}
