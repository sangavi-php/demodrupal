<?php

namespace Drupal\tfm_list\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "list_block",
 *   admin_label = @Translation("ListBlock"),
 *   category = @Translation("ListBlock"),
 * )
 */
class listBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = [];
    $data= " ";   
    $tid = 'Training Details';
    $aid = 'Assessment Details'; 
    $data .= '<a href="/tfp9314/training/add">'.$tid.'</a>'.'<br>';    
    $data .= '<a href="/tfp9314/assessment/add">'.$aid.'</a>'.'<br>';     
    $build = [
        '#markup' =>  $data,
    ];      
    return $build; 
    
  }
  
  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }
   

  // function MYTHEME_preprocess_page(&$variables) {myblocktrainlistblock

  //   // If sub-menu block is available.
  //   if (isset($variables['page']['sidebar_first']['menu_block_2'])) {
  
  //     // Unset its placeholder block.
  //     unset($variables['page']['sidebar_first']['block_3']);
  //   }
  // }
      
}