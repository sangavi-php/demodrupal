<?php

namespace Drupal\tfm_skillmenu\Plugin\Block;
use Drupal\Core\Block\BlockBase; 
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\taxonomy\Entity\Term;

/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "my_block_example_block",
 *   admin_label = @Translation("Myblock"),
 * )
 */
class MyBlock extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {  
    $build = []; 
    $data= "";
    $vid = 'primary_skill';
    $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid);  
     
       foreach ($terms as $term) {   
        $data .= '<a href="/tfp9314/adobe/'.$term->tid.'">'.$term->name.'</a>'.'<br>';    
      }
    
    $build =[
      '#markup' => $data,
    ];          
    return $build;     
  }     
  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->getConfiguration();
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['my_block_settings'] = $form_state->getValue('my_block_settings');
  }
}